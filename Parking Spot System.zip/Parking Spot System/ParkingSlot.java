
/**
 * Write a description of class ParkingSlot here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ParkingSlot
{
    // instance variables - replace the example below with your own
    private String slotID;
    private String slotType;

    /**
     * Constructor for objects of class ParkingSlot
     */
    public ParkingSlot(String slotID, String slotType)
    {
        // initialise instance variables
        this.slotID = slotID;
        this.slotType= slotType;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
  public String getSlotID()
  {
      System.out.println("this is show slot");
    return slotID;
    
    }
    
     public String getSlotType()
  {
    return slotType;
    
    }
}
