
/**
 * Write a description of class Application here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
import java.util.Random;
import java.util.*;

public class Application
{
    // instance variables - replace the example below with your own
    public static void main(String args[]){
    
    int opt1 = 1;
    int opt2 = 2;
    int opt3 = 3;
    int opt4 = 4;
    int opt5 = 5;
    int opt6 = 6;
    int usrInput;
    
    String slot;
    String type;
  
    
   CarPark p1= new CarPark();
   
    Scanner reader = new Scanner(System.in);
do{
    System.out.println("########################################");
    System.out.println("## - Welcome to Parking Spot System - ##");
    System.out.println("########################################");
    System.out.println("========================================");
    System.out.println("-------------- Menu --------------------");
    System.out.println("");
    System.out.println("1 - Add a parking slot.");
    System.out.println("2 - Delete a parking slot(only if not occupied)");
    System.out.println("3 - List all slots");
    System.out.println("4 - Park a car in to a slot");
    System.out.println("5 - Find a car");
    System.out.println("6 - Remove a car");
    System.out.println("========================================");
    
    
    
    
    
    
        System.out.println("Please select a number from above options");
    usrInput = reader.nextInt();
    
    switch(usrInput){
    
 
       case 1:
        System.out.println("option 1");
        Scanner scan = new Scanner(System.in);
        
          System.out.println("Enter slot: ");
                slot = scan.next();
                System.out.println(" Enter type: ");
                type = scan.next();
                
                p1.addParkingSlot(slot, type);
  
    break;
  
        
        case 2:
        System.out.println("option 2");
        
        break;

        
         case 3:
        System.out.println("option 3");
        p1.showSlot();
         break;
     
        case 4:
        System.out.println("option 4");
         
             break;
    
        case 5:
        
        System.out.println("option 5");
         break;
   
        
       case 6:
        System.out.println("option 6");
        break;
    
        
        
    default:
    System.out.println("Please select a valid option number (1-6). ");

  
  
    }
}while(usrInput > 6);
    }
}
