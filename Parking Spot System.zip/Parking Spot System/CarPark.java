
/**
 * Write a description of class CarPark here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
import java.util.ArrayList;
public class CarPark
{
    // instance variables - replace the example below with your own
   
 ArrayList<ParkingSlot> slot = new ArrayList<ParkingSlot>();
  String slotID;
 String slotType;
 ParkingSlot s1 = new ParkingSlot(slotID, slotType);
    /**
     * Constructor for objects of class CarPark
     */
   /** public CarPark(String slotID,String slotType)
    {
        // initialise instance variables
  
        slot = new ArrayList<ParkingSlot>();
        slotID = slotID;
        slotType = slotType;
        
    }*/

   public void addParkingSlot(String slotID, String slotType)
   {
        System.out.println("this is show slot ID" + slotID + "this is type" + slotType);
    slot.add(s1);
    
    }
    
    public void showSlot(){

        System.out.println("this is show slot");
    s1.getSlotID();
    }
}
